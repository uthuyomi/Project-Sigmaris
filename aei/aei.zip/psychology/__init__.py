from .longterm import LongTermPsychology

__all__ = [
    "LongTermPsychology",
]